package com.ems.bdsqlitefull.crud;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ems.bdsqlitefull.R;
import com.ems.bdsqlitefull.pojo.Cliente;

public class Detalhe extends AppCompatActivity {
    Button btEditar;
    TextView id, cpf, nome, endereco, email;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        // Mostra um botão na Barra Superior para voltar
        getSupportActionBar().setTitle("Detalhes");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        id = findViewById(R.id.id);
        cpf = findViewById(R.id.cpf);
        nome = findViewById(R.id.nome);
        endereco = findViewById(R.id.endereco);
        email = findViewById(R.id.email);
        btEditar = findViewById(R.id.btSalvar);

        Intent itAluno = getIntent();
        final Cliente cliente = (Cliente) itAluno.getExtras().getSerializable("objCliente");
        id.setText(String.valueOf(cliente.getId()));
        cpf.setText(cliente.getCpf());
        nome.setText(cliente.getNome());
        endereco.setText(cliente.getEndereco());
        email.setText(cliente.getEmail());

        btEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent editar = new Intent(getApplicationContext(), Editar.class);
                editar.putExtra("objCliente", cliente);
                startActivity(editar);
            }
        });
    }

    // Configura o botão (seta) na ActionBar (Barra Superior)
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}