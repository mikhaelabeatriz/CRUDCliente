package com.ems.bdsqlitefull.pojo;

import java.io.Serializable;

// POJO - Plain Old Java Objects
public class Cliente implements Serializable {
    private int id;
    private String cpf;
    private String nome;
    private String endereco;
    private String email;

    /**
     * Método construtor vazio
     */
    public Cliente() {
    }

    /*
     * Método construtor da classe com assinatura
     *
     * @param ra
     * @param nome
     * @param curso
     * @param campus
     */
    public Cliente(String cpf, String nome, String endereco) {
        this.cpf = cpf;
        this.nome = nome;
        this.endereco = endereco;
        //this.campus = campus;
    }

    /**
     * Método construtor da classe com assinatura
     *
     * @param id
     * @param cpf
     * @param nome
     * @param endereco
     * @param email
     */
    public Cliente(int id, String cpf, String nome, String endereco, String email) {
        this.id = id;
        this.cpf = cpf;
        this.nome = nome;
        this.endereco = endereco;
        //this.campus = campus;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDados() {
        return "ID: " + id + "\n" +
                "CPF: " + cpf + "\n" +
                "Nome: " + nome + "\n" +
                "Endereço: " + endereco + '\n';}
}