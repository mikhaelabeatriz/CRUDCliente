package com.ems.bdsqlitefull.crud;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ems.bdsqlitefull.MainActivity;
import com.ems.bdsqlitefull.R;
import com.ems.bdsqlitefull.pojo.Cliente;
import com.ems.bdsqlitefull.utils.Message;

public class Editar extends AppCompatActivity {

    TextView id;
    EditText cpf, nome, endereco, email;
    Button btSalvar;

    SQLiteDatabase db;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        // Mostra um botão na Barra Superior para voltar
        getSupportActionBar().setTitle("Editar clientes");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        id = findViewById(R.id.id);
        cpf = findViewById(R.id.cpf);
        nome = findViewById(R.id.nome);
        endereco = findViewById(R.id.endereco);
        email = findViewById(R.id.email);
        btSalvar = findViewById(R.id.btSalvar);

        final Intent itAluno = getIntent();
        final Cliente cliente = (Cliente) itAluno.getExtras().getSerializable("objCliente");
        id.setText(String.valueOf(cliente.getId()));
        cpf.setText(cliente.getCpf());
        nome.setText(cliente.getNome());
        endereco.setText(cliente.getEndereco());
        email.setText(cliente.getEmail());

        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Coleta os dados digitados
                ContentValues values = new ContentValues();
                values.put("cpf", cliente.getCpf());
                values.put("nome", cliente.getNome());
                values.put("endereço", cliente.getEndereco());
                values.put("email", cliente.getEmail());

                Cliente novosDados = new Cliente();
                novosDados.setCpf(cpf.getText().toString());
                novosDados.setNome(nome.getText().toString());
                novosDados.setEndereco(endereco.getText().toString());
                novosDados.setEmail(email.getText().toString());

                // Atualiza os dados na tabela
                db = openOrCreateDatabase("cliente_db", Context.MODE_PRIVATE, null);
                db.execSQL("UPDATE cliente SET " +
                        "cpf='" + novosDados.getCpf() + "'," +
                        "nome='" + novosDados.getNome() + "'," +
                        "endereco='" + novosDados.getEndereco() + "'," +
                        "email='" + novosDados.getEmail() + "' " +
                        "WHERE id=" + cliente.getId()
                );

                // Cria uma caixa de mensagem e mostra os dados incluídos
                Message message = new Message(Editar.this);
                message.show(
                        "Dados do cliente atualizados!",
                        novosDados.getDados(),
                        R.drawable.ic_add);
                ;
                Intent main = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(main);
            }
        });
    }

    // Configura o botão de voltar
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}