package com.ems.bdsqlitefull;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.ems.bdsqlitefull.crud.Inserir;
import com.ems.bdsqlitefull.crud.Listar;

public class MainActivity extends AppCompatActivity {
    // declara os botões da tela principal
    Button btInsert, btList, btSearch, btExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Configura o botão inserir
        btInsert = findViewById(R.id.btMainInsert);
        btInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent insert = new Intent(getApplicationContext(), Inserir.class);
                // abre uma nova tela
                startActivity(insert);
            }
        });

        // Configura o botao listar
        btList = findViewById(R.id.btMainList);
        btList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent insert = new Intent(getApplicationContext(), Listar.class);
                // abre uma nova janela
                startActivity(insert);
            }
        });

        // Configura o botao sair
        btExit = findViewById(R.id.btMainExit);
        btExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Finaliza a aplicação
                finishAffinity();
            }
        });
    }
}
