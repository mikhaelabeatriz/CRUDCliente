# ANDROID CRUD SQLite
This project shows implementation for CRUD using the SQLite in Android

Este projeto mostra a implementação de um CRUD em Android utilizando SQLite 
